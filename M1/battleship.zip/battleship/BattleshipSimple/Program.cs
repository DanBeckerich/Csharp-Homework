﻿//base code provided on Blackboard
//modified by Daniel Beckerich on 3/22/2018
//this is a console version of Battleship
using System;
using System.Linq;
using System.Collections.Generic;


namespace BattleshipSimple
{
    class Program
    {
        //current test grid
        private static readonly char[,] Grid = new char[,]
        {
            {'.', '.', '.', '.', 'S', 'S', 'S', '.', '.', '.'},
            {'P', 'P', '.', '.', '.', '.', '.', '.', '.', '.'},
            {'.', '.', '.', '.', '.', '.', '.', '.', '.', 'P'},
            {'.', '.', '.', '.', '.', '.', '.', '.', '.', 'P'},
            {'.', '.', 'A', 'A', 'A', 'A', 'A', '.', '.', '.'},
            {'.', '.', '.', '.', '.', '.', '.', 'B', '.', '.'},
            {'.', 'S', '.', '.', '.', '.', '.', 'B', '.', '.'},
            {'.', 'S', '.', '.', '.', '.', '.', 'B', 'P', 'P'},
            {'.', 'S', '.', '.', '.', '.', '.', 'B', '.', '.'},
            {'.', '.', '.', '.', '.', '.', '.', '.', '.', '.'},
        };

        //define a struct, this will contain both the row and column of the players guess.
        public struct coordinate
        {
            public char Column;
            public int Row;
        }

        static void Main(string[] args)
        {
            //declare variables.
            //Save the default console color for later use
            ConsoleColor planeForground = Console.ForegroundColor;
            //the Dictionary is used to convert char's to a designated color.
            Dictionary<char, ConsoleColor> ShipColors = new Dictionary<char, ConsoleColor>();
            coordinate parsedUserData;

            //add the different colors to the dictionary.
            ShipColors.Add('S', ConsoleColor.Blue);
            ShipColors.Add('P', ConsoleColor.Cyan);
            ShipColors.Add('A', ConsoleColor.Green);
            ShipColors.Add('B', ConsoleColor.Yellow);
            ShipColors.Add('.', planeForground);
            //and now a dictionary to convert a letter coordniate to a number corisponding to an array location.
            Dictionary<char, int> letterToNumber = new Dictionary<char, int>();
            letterToNumber.Add('A', 0);
            letterToNumber.Add('B', 1);
            letterToNumber.Add('C', 2);
            letterToNumber.Add('D', 3);
            letterToNumber.Add('E', 4);
            letterToNumber.Add('F', 5);
            letterToNumber.Add('G', 6);
            letterToNumber.Add('H', 7);
            letterToNumber.Add('I', 8);
            letterToNumber.Add('J', 9);

            //main game loop
            while (true)
            {
                //each iteration, draw the top row of letters from A to J
                Console.WriteLine("  A-B-C-D-E-F-G-H-I-J ");

                //itterate through the rows
                for (int row = 0; row < 10; row++)
                {
                    //and columns
                    for (int column = 0; column < 10; column++)
                    {
                        //if we are on the first column of the line, add the row number.
                        if (column == 0)
                        {
                            Console.Write("{0,2}", row + 1);
                        }

                        //if there is a hit at that location, set it to red and print an X
                        if (Grid[row, column] == 'H')
                        {
                            Console.ForegroundColor = ConsoleColor.Red;
                            Console.Write("X");
                            Console.ForegroundColor = planeForground;
                        }
                        else if (Grid[row,column] == 'M')
                        {
                            Console.Write("X");
                        }
                        //if there is a miss at the location, set the color to 
                        else
                        {

                        Console.ForegroundColor = ShipColors[Grid[row, column]];
                        Console.Write(Grid[row, column]);
                        Console.ForegroundColor = planeForground;

                        }

                        //add the last peice of the grid to the row
                        Console.Write("|");
                    }
                    //end the current line and print the next bar to the console.
                    Console.WriteLine();
                    Console.WriteLine(" #-#-#-#-#-#-#-#-#-#-#");
                }

                //tell the user to enter a guess, with the format LetterNumber
                parsedUserData = GetUserData();

                //check to see if you hit something.
                if(Grid[parsedUserData.Row, letterToNumber[parsedUserData.Column]] != '.')
                {
                    //if you did hit something, then set that location to H to denote a hit
                    Grid[parsedUserData.Row, letterToNumber[parsedUserData.Column]] = 'H';
                }
                else
                {
                    Grid[parsedUserData.Row, letterToNumber[parsedUserData.Column]] = 'M';
                }

            }
        }

         public static coordinate GetUserData()
        {
            //define the variables
            bool isDataValid = true;
            string rawUserData;
            char[] Validcoordinates = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J' };
            char lettercoordinate = 'A';
            int numbercoordinate = 1;

            //repeat until the data is valid.
            do
            {
                Console.WriteLine("Please enter your guess in the format LetterNumber: ");
                rawUserData = Console.ReadLine();

                //several tests for the string, to make sure its valid information before we parse and return.
                if (rawUserData.Length > 3 & rawUserData.Length > 0) isDataValid = false;
                else if (!char.IsLetter(rawUserData[0])) isDataValid = false;
                else if (!Validcoordinates.Contains(rawUserData[0])) isDataValid = false;
                //if none of the if statements exicute, then parse the data
                else
                {
                    if(rawUserData.Length == 2)
                    {
                        lettercoordinate = rawUserData[0];
                        numbercoordinate = int.Parse(rawUserData[1].ToString()) - 1;
                    }
                    else
                    {
                        lettercoordinate = rawUserData[0];
                        numbercoordinate = int.Parse(rawUserData.Substring(1)) - 1;
                    }

                }

            } while (isDataValid = false);

            coordinate output = new coordinate();
            output.Column = lettercoordinate;
            output.Row = numbercoordinate;

            return output;
        }
    }
}
