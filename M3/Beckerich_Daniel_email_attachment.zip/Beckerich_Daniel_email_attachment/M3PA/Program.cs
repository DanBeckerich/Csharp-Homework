﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M3PA
{
    class Program
    {
        static void Main(string[] args)
        {

            Carrier ac = new Carrier();
            ac.place(new position(0, 0), ship.Direction.Horizontal);
            ac.reset();

            grid main = new grid(10, 10);
            main.AddShip(ac);
            main.draw();


            Console.ReadLine();
        }
    }
}
