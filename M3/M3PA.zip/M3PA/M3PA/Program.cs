﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M3PA
{
    class Program
    {
        static void Main(string[] args)
        {

            Carrier ac = new Carrier();
            Console.WriteLine(ac.isBattleship);
            ac.place(new position(1, 1), ship.Direction.Vertical);
            ac.reset();


            Console.ReadLine();
        }
    }
}
