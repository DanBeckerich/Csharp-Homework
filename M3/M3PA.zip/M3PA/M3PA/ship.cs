﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace M3PA
{
    internal struct position
    {
        internal int Xpos;
        internal int Ypos;
       public position(int newX, int newY)
       {
            this.Xpos = newX;
            this.Ypos = newY;
       }

       public position(position newPosition)
        {
            this.Xpos = newPosition.Xpos;
            this.Ypos = newPosition.Ypos;
        }

    }

    //ship class
    class ship
    {
        public int length { set; get; }
        ConsoleColor Color;
        public bool isSunk = false;
        public bool isBattleship = false;
        List<position> locations = new List<position>();

        internal enum Direction
        {
            Vertical,
            Horizontal
        };

        public int getLength()
        {
            return length;
        }

        public ConsoleColor getColor()
        {
            return Color;
        }

       public void reset()
        {
            length = 1;
            Color = ConsoleColor.Gray;
            isSunk = false;
            isBattleship = false;
        }

        public void place(position start, Direction facing)
        {
            locations.Add(new position(start));
            position temp = new position();

            if (facing == Direction.Vertical) {
                for (int i = 0; i < length; i++)
                {
                    temp.Xpos = start.Xpos + i;
                    temp.Ypos = start.Ypos;
                    locations.Add(temp);
                }
            }
            else
            {
                for (int i = 0; i < length; i++)
                {
                    temp.Xpos = start.Xpos;
                    temp.Ypos = start.Ypos + i;
                    locations.Add(temp);
                }
            }
        }


    }

    class Destroyer : ship
    {
        public Destroyer()
        {
            length = 2;
        }
    }

    class Submarine : ship
    {
        public Submarine()
        {
            length = 3;
        }
    }

    class Cruiser : ship
    {
        public Cruiser()
        {
            length = 3;
        }
    }

    class Battleship : ship
    {
        public Battleship()
        {
            length = 4;
            isBattleship = true;
        }
    }

    class Carrier : ship
    {
        public Carrier()
        {
            length = 5;
        }
    }
}
